const DAY = 864e5, LOAN_DAYS = 7;
const USERS = [{id:'u1',name:'Aarav (Student A)'},{id:'u2',name:'Meera (Student B)'},{id:'u3',name:'Rohan (Student C)'}];
const DEPT = {CS:'Computer Science',EE:'Electrical',ME:'Mechanical',CE:'Civil',MA:'Mathematics',PH:'Physics',CH:'Chemistry',BT:'Biotechnology',IE:'Industrial'};
const SEED = `Operating System Concepts|Galvin|CS301
Introduction to Algorithms|Cormen|CS201
Computer Networks|Tanenbaum|CS302
Database System Concepts|Silberschatz|CS303
Artificial Intelligence: A Modern Approach|Russell & Norvig|CS401
Computer Organization and Design|Patterson & Hennessy|CS202
Compilers: Principles, Techniques, and Tools|Aho|CS402
The C Programming Language|Kernighan & Ritchie|CS101
Microelectronic Circuits|Sedra & Smith|EE201
Signals and Systems|Oppenheim|EE301
Fundamentals of Electric Circuits|Alexander & Sadiku|EE101
Digital Design|Mano|EE202
Power System Analysis|Grainger|EE401
Engineering Mechanics: Statics|Hibbeler|ME101
Fluid Mechanics|White|ME301
Heat and Mass Transfer|Cengel|ME302
Shigley's Mechanical Engineering Design|Budynas|ME401
Thermodynamics: An Engineering Approach|Cengel|ME201
Structural Analysis|Hibbeler|CE301
Principles of Geotechnical Engineering|Das|CE302
Advanced Engineering Mathematics|Kreyszig|MA201
Linear Algebra and Its Applications|Lay|MA102
Calculus: Early Transcendentals|Stewart|MA101
Probability and Statistics for Engineers|Walpole|MA301
Discrete Mathematics and Its Applications|Rosen|MA202
University Physics|Young & Freedman|PH101
Introduction to Electrodynamics|Griffiths|PH301
Introduction to Quantum Mechanics|Griffiths|PH302
Concepts of Modern Physics|Beiser|PH201
Organic Chemistry|Clayden|CH201
Physical Chemistry|Atkins|CH301
Chemistry: The Central Science|Brown|CH101
Campbell Biology|Urry|BT101
Molecular Biology of the Cell|Alberts|BT301
Engineering Economy|Blank|IE201`;

let S, view = 'catalog', q = '', dept = '', avail = '';
const notified = new Set();

function fresh(){
  const conds = ['Good','Like new','Fair'];
  return {offset:0, me:'u1', reqs:[], books: SEED.split('\n').map((l,i)=>{
    const [title,author,code]=l.split('|');
    return {id:'b'+i,title,author,code,edition:(3+i%6)+'th',condition:conds[i%3],owner:USERS[i%3].id,on:true};
  })};
}
function load(){ try{ S = JSON.parse(localStorage.getItem('pagevault')) }catch(e){} if(!S) S = fresh(); }
function save(){ try{ localStorage.setItem('pagevault', JSON.stringify(S)) }catch(e){} }
const now = () => Date.now() + S.offset*DAY;
const esc = s => String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uname = id => USERS.find(u=>u.id===id).name.split(' ')[0];
const bookOf = id => S.books.find(b=>b.id===id);
const openReq = b => S.reqs.find(r=>r.bookId===b.id && (r.status==='pending'||r.status==='approved'));
function status(b){
  const r = openReq(b);
  if(r) return r.status==='approved' ? 'Borrowed' : 'Reserved';
  return b.on ? 'Available' : 'Paused';
}
function toast(m){ const t=document.getElementById('toast'); t.textContent=m; t.style.display='block'; clearTimeout(t._t); t._t=setTimeout(()=>t.style.display='none',2600); }

function cover(b){
  let h=0; for(const c of b.code+b.title) h=(h*31+c.charCodeAt(0))%360;
  const words=b.title.split(' '), lines=[]; let cur='';
  words.forEach(w=>{ if((cur+' '+w).trim().length>20){lines.push(cur);cur=w}else cur=(cur+' '+w).trim() }); lines.push(cur);
  const t=lines.slice(0,4).map((l,i)=>`<text x="16" y="${44+i*20}" font-size="15" font-weight="700" fill="#fff">${esc(l)}</text>`).join('');
  return `<svg viewBox="0 0 230 150" role="img" aria-label="Cover of ${esc(b.title)}"><rect width="230" height="150" fill="hsl(${h} 45% 30%)"/><rect x="0" y="0" width="10" height="150" fill="hsl(${h} 50% 20%)"/>${t}<text x="16" y="136" font-size="14" fill="#f5c55a" font-weight="800">${esc(b.code)}</text></svg>`;
}

function setView(v){ view=v; document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===v)); render(); }
function skip(n){ S.offset+=n; save(); render(); toast('Clock moved to '+new Date(now()).toDateString()); }
function resetAll(){ if(confirm('Reset all demo data?')){ S=fresh(); save(); render(); } }

/* ---------- actions ---------- */
function request(id){
  const b=bookOf(id);
  if(status(b)!=='Available') return toast('Someone else just requested this book.');
  if(b.owner===S.me) return toast('This is your own book.');
  S.reqs.push({id:'r'+Date.now(),bookId:id,borrower:S.me,status:'pending',requested:now()}); // flips to Reserved instantly
  save(); render(); toast('Request sent to '+uname(b.owner));
}
function decide(rid,ok){
  const r=S.reqs.find(x=>x.id===rid);
  if(ok){ r.status='approved'; r.due=now()+LOAN_DAYS*DAY; toast('Approved. Due in '+LOAN_DAYS+' days.'); }
  else { r.status='rejected'; toast('Request declined.'); }
  save(); render();
}
function giveBack(rid){ const r=S.reqs.find(x=>x.id===rid); r.status='returned'; r.returned=now(); save(); render(); toast('Marked as returned.'); }
function toggle(id){ const b=bookOf(id); b.on=!b.on; save(); render(); }
function addBook(e){
  e.preventDefault(); const f=e.target, v=n=>f[n].value.trim(), errs=[];
  const code=v('code').toUpperCase();
  if(v('title').length<2) errs.push('Enter the book title.');
  if(v('author').length<2) errs.push('Enter the author.');
  if(!/^[A-Z]{2,4}\d{3}$/.test(code)) errs.push('Course code looks like CS201 (2–4 letters, 3 digits).');
  if(errs.length){ document.getElementById('err').innerHTML=errs.join('<br>'); return; }
  S.books.unshift({id:'b'+Date.now(),title:v('title'),author:v('author'),edition:v('edition')||'1st',code,condition:f.condition.value,owner:S.me,on:f.on.checked});
  save(); toast('Book listed.'); setView('catalog');
}

/* ---------- views ---------- */
function catalog(){
  const t=q.toLowerCase();
  const list=S.books.filter(b=>{
    const d=DEPT[b.code.replace(/\d/g,'')]||'';
    const hit=!t||[b.title,b.code,d,b.author].some(x=>x.toLowerCase().includes(t));
    return hit && (!dept||b.code.startsWith(dept)) && (!avail||status(b)===avail);
  });
  const opts=Object.entries(DEPT).map(([k,v])=>`<option value="${k}" ${dept===k?'selected':''}>${v}</option>`).join('');
  const cards=list.map(b=>{
    const s=status(b), mine=b.owner===S.me;
    return `<article class="card">${cover(b)}<div class="b"><h4>${esc(b.title)}</h4>
      <div class="meta">${esc(b.author)} · ${esc(b.edition)} ed.</div>
      <div class="meta">${esc(b.condition)} · from ${esc(uname(b.owner))}</div>
      <span class="badge ${s}">${s}</span>
      <div class="row"><button class="btn" ${s!=='Available'||mine?'disabled':''} onclick="request('${b.id}')">${mine?'Your book':'Request borrow'}</button></div></div></article>`;
  }).join('');
  return `<h2>Find a textbook</h2><p class="sub">Search by course code (try CS301), title, author or department.</p>
  <div class="tools"><input id="q" type="search" placeholder="Search…" value="${esc(q)}" aria-label="Search books">
  <select id="dept" aria-label="Department"><option value="">All departments</option>${opts}</select>
  <select id="avail" aria-label="Availability"><option value="">Any status</option>${['Available','Reserved','Borrowed'].map(x=>`<option ${avail===x?'selected':''}>${x}</option>`).join('')}</select></div>
  <p class="meta" id="n">${list.length} book${list.length===1?'':'s'} found</p>
  ${list.length?`<div class="grid" id="grid">${cards}</div>`:'<div class="empty">No books match. Clear a filter or list the book yourself.</div>'}`;
}
function listForm(){
  return `<h2>List a book</h2><p class="sub">Add a textbook you can lend to other students.</p>
  <form onsubmit="addBook(event)" novalidate>
    <label class="full">Title<input name="title" required></label>
    <label>Author<input name="author" required></label>
    <label>Edition<input name="edition" placeholder="e.g. 10th"></label>
    <label>Course code<input name="code" placeholder="CS301" required></label>
    <label>Condition<select name="condition"><option>Like new</option><option selected>Good</option><option>Fair</option><option>Worn</option></select></label>
    <label class="full" style="flex-direction:row;align-items:center"><input type="checkbox" name="on" checked style="min-width:auto"> Available to borrow now</label>
    <div class="full err" id="err"></div>
    <div class="full"><button class="btn">List this book</button></div>
  </form>`;
}
function left(r){
  const ms=r.due-now(), d=Math.ceil(ms/DAY);
  if(ms<0) return {t:`Overdue by ${Math.ceil(-ms/DAY)} day${Math.ceil(-ms/DAY)>1?'s':''}`,c:'late'};
  if(d<=2) return {t:`${d} day${d>1?'s':''} left`,c:'soon'};
  return {t:`${d} days left`,c:''};
}
function mine(){
  const myBooks=S.books.filter(b=>b.owner===S.me);
  const incoming=S.reqs.filter(r=>r.status==='pending'&&bookOf(r.bookId).owner===S.me);
  const out=S.reqs.filter(r=>r.status==='approved'&&bookOf(r.bookId).owner===S.me);
  const bor=S.reqs.filter(r=>r.borrower===S.me&&(r.status==='approved'||r.status==='pending'));
  const hist=S.reqs.filter(r=>(r.borrower===S.me||bookOf(r.bookId).owner===S.me)&&(r.status==='returned'||r.status==='rejected'));
  const L=(arr,fn,msg)=>arr.length?`<div class="list">${arr.map(fn).join('')}</div>`:`<div class="empty">${msg}</div>`;
  return `<h2>My exchanges</h2><p class="sub">Signed in as ${esc(uname(S.me))}.</p>
  <h3>Requests waiting for you</h3>${L(incoming,r=>{const b=bookOf(r.bookId);return `<div class="item"><span><b>${esc(uname(r.borrower))}</b> wants <b>${esc(b.title)}</b> (${esc(b.code)})</span><span class="row"><button class="btn ok" onclick="decide('${r.id}',true)">Approve</button><button class="btn no" onclick="decide('${r.id}',false)">Decline</button></span></div>`},'No pending requests.')}
  <h3>Books I'm borrowing</h3>${L(bor,r=>{const b=bookOf(r.bookId);
    if(r.status==='pending') return `<div class="item"><span><b>${esc(b.title)}</b><br><span class="meta">Waiting for ${esc(uname(b.owner))} to approve</span></span><span class="badge Reserved">Pending</span></div>`;
    const l=left(r);return `<div class="item"><span><b>${esc(b.title)}</b><br><span class="meta">From ${esc(uname(b.owner))} · due ${new Date(r.due).toDateString()}</span></span><span class="count ${l.c}">${l.t}</span></div>`},'You have no borrowed books. Find one in the catalog.')}
  <h3>Books I've lent out</h3>${L(out,r=>{const b=bookOf(r.bookId),l=left(r);return `<div class="item"><span><b>${esc(b.title)}</b><br><span class="meta">With ${esc(uname(r.borrower))}</span></span><span class="count ${l.c}">${l.t}</span><button class="btn" onclick="giveBack('${r.id}')">Mark returned</button></div>`},'Nothing lent out right now.')}
  <h3>My listed books</h3>${L(myBooks,b=>{const s=status(b);return `<div class="item"><span><b>${esc(b.title)}</b> <span class="meta">${esc(b.code)}</span></span><span class="row" style="margin:0;padding:0"><span class="badge ${s}">${s}</span><button class="btn alt" ${openReq(b)?'disabled':''} onclick="toggle('${b.id}')">${b.on?'Pause listing':'Make available'}</button></span></div>`},'You have not listed any books yet.')}
  <h3>History</h3>${L(hist,r=>{const b=bookOf(r.bookId);return `<div class="item"><span>${esc(b.title)} · ${esc(uname(r.borrower))} borrowing from ${esc(uname(b.owner))}</span><span class="meta">${r.status==='returned'?'Returned '+new Date(r.returned).toDateString():'Declined'}</span></div>`},'No finished exchanges yet.')}`;
}

/* ---------- reminders ---------- */
function reminders(){
  let h='';
  S.reqs.filter(r=>r.status==='approved'&&r.borrower===S.me).forEach(r=>{
    const l=left(r), b=bookOf(r.bookId);
    if(l.c){
      h+=`<div class="banner ${l.c==='late'?'late':'soon'}"><span>${l.c==='late'?'Overdue':'Due soon'}: return “${esc(b.title)}” to ${esc(uname(b.owner))}. ${l.t}.</span></div>`;
      const k=r.id+l.c+l.t;
      if(!notified.has(k)){ notified.add(k); try{ if(window.Notification&&Notification.permission==='granted') new Notification('PageVault reminder',{body:b.title+': '+l.t}); }catch(e){} }
    }
  });
  S.reqs.filter(r=>r.status==='approved'&&bookOf(r.bookId).owner===S.me&&left(r).c==='late').forEach(r=>{
    h+=`<div class="banner late"><span>${esc(uname(r.borrower))} has not returned “${esc(bookOf(r.bookId).title)}”.</span></div>`;
  });
  if(window.Notification&&Notification.permission==='default') h+=`<div class="banner info"><span>Turn on browser alerts for return reminders.</span><button class="btn" onclick="Notification.requestPermission().then(render)">Enable alerts</button></div>`;
  document.getElementById('banners').innerHTML=h;
}

function render(){
  document.getElementById('clock').textContent=new Date(now()).toDateString();
  const el=document.getElementById('view');
  el.innerHTML = view==='catalog'?catalog():view==='list'?listForm():mine();
  if(view==='catalog'){
    const qi=document.getElementById('q');
    qi.oninput=e=>{q=e.target.value; filterOnly(); };
    document.getElementById('dept').onchange=e=>{dept=e.target.value;render()};
    document.getElementById('avail').onchange=e=>{avail=e.target.value;render()};
  }
  reminders();
}
function filterOnly(){ // keep input focus while typing: re-render only the results
  const pos=document.getElementById('q').selectionStart; render();
  const qi=document.getElementById('q'); qi.focus(); qi.setSelectionRange(pos,pos);
}

document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>setView(b.dataset.v));
load();
const sel=document.getElementById('me');
sel.innerHTML=USERS.map(u=>`<option value="${u.id}">${u.name}</option>`).join('');
sel.value=S.me;
sel.onchange=e=>{S.me=e.target.value;save();render()};
render();
